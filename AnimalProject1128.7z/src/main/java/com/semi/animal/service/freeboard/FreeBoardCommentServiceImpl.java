package com.semi.animal.service.freeboard;

import org.springframework.stereotype.Service;

@Service
public class FreeBoardCommentServiceImpl implements FreeBoardCommentService {
	

	
	
}
