package com.semi.animal.service.freeboard;

public interface FreeBoardCommentService {
	
	
	
	
}
