package com.semi.animal.controller.freeboard;

import org.springframework.stereotype.Controller;

@Controller
public class FreeBoardCommentController {

	

	
		
	
}
