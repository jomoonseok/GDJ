package com.semi.animal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.semi.animal.domain.UserDTO;


@Mapper
public interface AdminMapper {
	
	public int selectUserListCount();
	public List<UserDTO> selectUserListByMap(Map<String, Object> map);
	public int deleteUser(String id);
	
}
