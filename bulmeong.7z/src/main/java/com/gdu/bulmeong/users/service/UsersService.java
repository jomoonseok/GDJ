package com.gdu.bulmeong.users.service;

public interface UsersService {

}
