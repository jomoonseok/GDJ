package com.gdu.bulmeong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BulmeongApplication {

	public static void main(String[] args) {
		SpringApplication.run(BulmeongApplication.class, args);
	}

}
