package com.gdu.bulmeong.ex.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BulMeongMapper {
	
}
