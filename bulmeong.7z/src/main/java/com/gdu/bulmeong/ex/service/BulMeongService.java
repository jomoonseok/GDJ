package com.gdu.bulmeong.ex.service;

public interface BulMeongService {

}
