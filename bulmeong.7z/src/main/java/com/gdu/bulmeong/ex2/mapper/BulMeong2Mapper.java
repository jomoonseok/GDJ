package com.gdu.bulmeong.ex2.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BulMeong2Mapper {
	
}
