package com.gdu.bulmeong.ex2.service;

public interface BulMeong2Service {

}
