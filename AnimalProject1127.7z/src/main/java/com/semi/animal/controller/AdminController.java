package com.semi.animal.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.semi.animal.service.AdminService;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;

	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/admin/main")
	public String list() {
		return "admin/main";
	}
	
	@GetMapping("/admin/userList")
	public String userList(HttpServletRequest request, Model model){
		adminService.getUserList(request, model);
		return "admin/userList";
	}
	
	@GetMapping("/admin/removeUser")
	public void removeUser(HttpServletRequest request, HttpServletResponse response) {
		adminService.removeUser(request, response);
	}
	
	
	
	@GetMapping("/admin/freeboardList")
	public String list(HttpServletRequest request, Model model) {
		adminService.getFreeBoardList(request, model);
		return "admin/freeboardList";
	}
	
	@GetMapping("/admin/freeboardWrite")
	public String write() {
		return "admin/freeboardWrite";
	}
	
	@PostMapping("/admin/freeboardAdd")
	public void add(HttpServletRequest request, HttpServletResponse response) {
		adminService.addFreeBoard(request, response);
	}
	
	@GetMapping("/admin/freeboardDetail")
	public String detail(@RequestParam(value="freeNo", required=false, defaultValue="0") int freeNo, Model model) {
		
		model.addAttribute("free", adminService.getFreeBoardByNo(freeNo));
		return "admin/freeboardDetail";
	}
	
	
	@GetMapping("/admin/freeboardRemove")
	public void remove(HttpServletRequest request, HttpServletResponse response) {
		adminService.removeFreeBoard(request, response);
	}
	
}
