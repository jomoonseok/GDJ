package com.semi.animal.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;

import com.semi.animal.domain.FreeBoardDTO;

public interface AdminService {
	
	public void getUserList(HttpServletRequest request, Model model);
	public void removeUser(HttpServletRequest request, HttpServletResponse response);

	public void getFreeBoardList(HttpServletRequest request, Model model);
	public void addFreeBoard(HttpServletRequest request, HttpServletResponse response);
	public FreeBoardDTO getFreeBoardByNo(int freeNo);
	public void removeFreeBoard(HttpServletRequest request, HttpServletResponse response);










}
